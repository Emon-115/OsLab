package producerconsumer;

import java.util.Queue;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Producer implements Runnable {

    Semaphore mutex = null;
    Semaphore empty = null;
    Semaphore full = null;
    Queue<Integer> buffer = null;
    int count_produce;
    Random rand = new Random();
    private volatile boolean exit = false;

    public Producer(Semaphore mutex, Semaphore empty, Semaphore full, Queue<Integer> buffer) {
        this.mutex = mutex;
        this.empty = empty;
        this.full = full;
        this.buffer = buffer;
        this.count_produce = 0;
    }

    @Override
    public void run() {
        int item;

        while (true) {
            try {
                item = rand.nextInt(100) + 1;
                empty.down();
                mutex.down();
                buffer.add(item);
				//TASK: Write your code here
				//Producer reduces the value of empty, and increases the value of full
                
				//Add to the buffer the item generated above
                System.out.println(Thread.currentThread().getName()+" produced :"+ item);
                //Track the count of items produced by the consumer
				//Adding an item to the buffer is a critical operation, and no one else should have access to the buffer when an item is added!
				//After adding an item to the buffer, print: <Thread_Name> produced <Value_of_Item>, where <Thread_Name> is the name of
				//the running thread, and <Value_of_Item> is the item that was produced at the top of this iteration
                count_produce++;
                if(count_produce == 2)
                {
                    count_produce=0;
                    System.out.println("Two Producers Appear Consecutively");
                }
                 mutex.up();
                 full.up();
                

                Thread.sleep(rand.nextInt(30) + 1);
            } catch (InterruptedException ex) {
                Logger.getLogger(Producer.class.getName()).log(Level.SEVERE, null, ex);
            }
            if(exit){
                break;
            }
        }
    }

    //This function stops the above while loop and return the count of items
    public int stop()
    {
        exit = true;
        return this.count_produce;
    }
}
