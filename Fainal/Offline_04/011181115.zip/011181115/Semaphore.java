package producerconsumer;

public class Semaphore {

    private int initialValue = 0;
    private int upperBound = 0;
    private String name = null;

    public Semaphore(int initialValue, int upperBound, String name) {
        this.initialValue = initialValue;
        this.upperBound = upperBound;
         this.name = name;
    }

    public synchronized void up() throws InterruptedException {
        while (this.initialValue == upperBound) {
            System.out.println(Thread.currentThread().getName() + " is waiting in up for " + name + ":");
            wait();
        }
        this.initialValue+=1;
        System.out.println(Thread.currentThread().getName() + " performed up for " + name + ":");
        this.notify();
    }

    public synchronized void down() throws InterruptedException {
        //TASK: Implement the down function. You can take help from the up function whis has been fully implemented above.
        while (this.initialValue == upperBound) {
            System.out.println(Thread.currentThread().getName() + " is waiting in up for " + name + ":");
            wait();
        }
        this.initialValue--;
        System.out.println(Thread.currentThread().getName() + " performed up for " + name + ":");
        this.notify();
    }
}
