package producerconsumer;
import java.util.Date;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class ProducerConsumer {

    /**
     * @param args the command line arguments
     */


    public static void main(String[] args) {
        int N;

        try (Scanner sc = new Scanner(System.in)) {
            System.out.println("Enter the size of buffer: ");
            N = sc.nextInt();
        }
        
        Semaphore mutex = new Semaphore(1, 1, "mutex");
        //TASK: Edit the following two lines. You can take help from the mutex Semaphore which has been fully declared above
        Semaphore empty = new Semaphore( N-1,N-1,"empty"); //Replace NULL with a proper Semaphore. Name this Semaphore "empty". Remember what the initial value of empty should be.
        Semaphore full = new Semaphore( 0,N-1,"full"); //Replace NULL with a proper Semaphore. Name this Semaphore "full". Remember what the initial value of full should be.

        Queue<Integer> buffer = new LinkedList<Integer>();

        //Multiple Process er jonno
        Producer producer1 = new Producer(mutex, empty, full, buffer);
         Producer producer2 = new Producer(mutex,empty,full,buffer);
         Producer producer3 = new Producer(mutex,empty,full,buffer);
        Producer producer4 = new Producer(mutex,empty,full,buffer);
        Producer producer5 = new Producer(mutex,empty,full,buffer);

        Consumer consumer1 = new Consumer(mutex, empty, full, buffer);
          Consumer consumer2=new Consumer(mutex,empty,full,buffer);
            Consumer consumer3=new Consumer(mutex,empty,full,buffer);
             Consumer consumer4=new Consumer(mutex,empty,full,buffer);
             Consumer consumer5=new Consumer(mutex,empty,full,buffer);
 

        new Thread(producer1, "Producer 1").start();
        new Thread(consumer1, "Consumer 1").start();
        
        new Thread(producer2,"Producer 2").start();
        new Thread(consumer2,"Consumer 2").start();
        
        new Thread(producer3,"Producer 3").start();
        new Thread(consumer3,"Consumer 3").start();
         
        new Thread(producer4,"Producer 4").start();
        new Thread(consumer4,"Consumer 4").start();
          
        new Thread(producer5,"Producer 5").start();
        new Thread(consumer5,"Consumer 5").start();

        long startTime = System.currentTimeMillis();
        long elapsedTime = 0l;

        //Let's run the threads for 5 seconds
        //You can change the duration if you want to
        while (elapsedTime < 7*1000) {
            elapsedTime = (new Date()).getTime() - startTime;
        }

        System.out.println("Remaining items in buffer:"+ producer1.buffer);

        int count_produced = producer1.stop();
        int count_consumed = consumer1.stop();
        System.out.println("Consumer consumed total" + count_produced+ "items");
        System.out.println("Consumer consumed total" + count_consumed+ "items");

    }

}
