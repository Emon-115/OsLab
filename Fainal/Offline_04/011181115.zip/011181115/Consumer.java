package producerconsumer;

import java.util.Queue;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Consumer implements Runnable {

    Semaphore mutex = null;
    Semaphore empty = null;
    Semaphore full = null;
    Queue<Integer> buffer = null;
    int count_consumed;
    Random rand = new Random();
    private volatile boolean exit = false;

    public Consumer(Semaphore mutex, Semaphore empty, Semaphore full, Queue<Integer> buffer) {
        this.mutex = mutex;
        this.empty = empty;
        this.full = full;
        this.buffer = buffer;
        this.count_consumed = 0;
    }

    @Override
    public void run() {
        int item;
        while (true) {
            try {
				//TASK: Write your code here
				//Consumer reduces the value of full and increases the value of empty
                full.down();
                mutex.down();
                item=buffer.remove(); 
				//Extract into the item variable (declared above) the front item of your buffer

                //Track the count of items consumed by the consumer
                count_consumed++;
                if(count_consumed == 2)
                {
                    count_consumed=0;
                    System.out.println("Multiple process Consumed  Consecutively");
                }
                mutex.up();
                empty.up();
				//Removing an item from the buffer is a critical operation, and no one else should have access to the buffer when an item is removed!
				//After removing an item from the buffer, print: <Thread_Name> consumed <Value_of_Item>
				//<Thread_Name> is the name of the running thread, and <Value_of_Item> is the item that was extracted in this iteration
                System.out.println(Thread.currentThread().getName()+" consumed " +item);
				
                Thread.sleep(rand.nextInt(10) + 1);
            } catch (InterruptedException ex) {
                Logger.getLogger(Producer.class.getName()).log(Level.SEVERE, null, ex);
            }
            if(exit){
                break;
            }

        }
    }

    //This function stops the above while loop and return the count of items
    public int stop()
    {
        exit = true;
        return this.count_consumed;
    }

}
