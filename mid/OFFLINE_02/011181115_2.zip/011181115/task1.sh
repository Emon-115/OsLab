#!/bin/bash
if [ $# -eq 3 ]
then 
	touch $file1.txt
	
	mv $file1.txt $file2.txt
	
	var1=$3
	
	for((i=0; i<=$var1; i++))
	
		do
			read data
			
			echo $data	
		done
	
else 

	echo "Run the shell script which remain excatly three arguments"
fi

