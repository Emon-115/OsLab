#!/bin/bash
re='^[0-9]+$'
echo "Enter Your Number: " 

read number

if ! [[ $number =~ $re ]] ; 

then
   echo "Find an Error: It's Not a number" >&2; 
   exit 1
   
else 
	sumation
fi


sumation(){

	
	for(( i=1; i<=number; i++ ))
	do
		sum=$(expr 0 + i)
	done 
	
	echo $sum
	

}



